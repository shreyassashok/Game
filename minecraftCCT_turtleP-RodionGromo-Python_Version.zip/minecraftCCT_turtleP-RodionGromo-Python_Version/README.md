# minecraftCCT_turtleP
Turtle and HTTP server for Minecraft mod CC: Tweaked 1.16.4

Branch Python_Version made for HTTP server implementation in Python
